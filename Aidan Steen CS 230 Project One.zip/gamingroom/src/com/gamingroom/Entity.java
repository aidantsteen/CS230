package com.gamingroom;

public class Entity {

	//instance variable declarations
	protected long id;
	protected String name;
	
	protected Entity() {
		//protected instead of private to allow the children to view the constructor
	}
	
	public Entity(long id, String name) { //constructor -long and String parameter
		this.id = id;
		this.name = name;
	}
	
	public long getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	
	public String toString() {
		return "Entity [id=" + ", name=" + name + "]";
	}
	
}
