package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * @author coce@snhu.edu
 *
 */
public class Team extends Entity {
	private static List<Player> players = new ArrayList<Player>();
	
	/*
	 * Constructor with an identifier and name
	 */
	public Team(long id, String name) {
		this.id = id;
		this.name = name;
	}
	
	public Player addPlayer(String name) {//local player instance
		Player player = null;
		
		for (int i = 0; i < players.size() - 1; i++) {
			if(players.get(i).getName() == name) {
				player = players.get(i);
			}
		}
		
		if(player == null) {
			GameService service = GameService.getInstance();
		
		//  Use the GameService Reference to call the getNextPlayerId() to get the Id to designate the player.
		player = new Player(service.getNextPlayerId(), name);
		players.add(player);
	}
			
		return player;
}


	@Override
	public String toString() {
		return "Team [id=" + id + ", name=" + name + "]";
	}
}
