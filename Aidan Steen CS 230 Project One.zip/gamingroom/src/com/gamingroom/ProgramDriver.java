package com.gamingroom;

import java.util.Scanner;

/**
 * Application start-up program
 * 
 * @author coce@snhu.edu
 */
public class ProgramDriver {
	
	/**
	 * The one-and-only main() method
	 * 
	 * @param args command line arguments
	 */
	public static void main(String[] args) {
		
		int input = 0;
		Scanner userInput = new Scanner(System.in);

		
		// FIXME: obtain reference to the singleton instance
		GameService service = GameService.getInstance();
		Team team = Game.addTeam(null);

		
		System.out.println("\nAbout to test initializing game data...");
		
		// initialize with some game data
		Game game1 = service.addGame("Game #1");
		System.out.println(game1);
		Game game2 = service.addGame("Game #2");
		System.out.println(game2);
		Game game3 = service.addGame("Test");
		System.out.println(game3);
		String newInstance = userInput.nextLine();
		Game game4 = service.addGame(newInstance);
		System.out.println(game4);
		
		// use another class to prove there is only one instance
		SingletonTester tester = new SingletonTester();
		tester.testSingleton();
	}
}
